// Vue CLI runs prettier via eslint when `npm run lint` is run. This
// config file should help if you're running prettier manually, like
// through a IDE plugin
module.exports = {};
