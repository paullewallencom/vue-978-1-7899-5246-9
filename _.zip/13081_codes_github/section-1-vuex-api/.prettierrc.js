// We're using the default config for all sections
// The `npm run lint` command runs prettier via eslint, so
// this config isn't really necessary unless you're running prettier
// manually (like through a plugin in your editor).

module.exports = {};
