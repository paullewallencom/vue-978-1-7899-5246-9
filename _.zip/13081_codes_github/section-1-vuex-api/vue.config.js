module.exports = {
  lintOnSave: false
};
